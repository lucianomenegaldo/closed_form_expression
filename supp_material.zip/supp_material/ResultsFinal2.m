% April 2024
% code for generating all figures of the paper Nunes et al., A closed-form expression for the relationship between shear modulus from shear wave elastography and tangent modulus from tensile test
% Federal Univeristy Fluminense, Federal University of Rio de Janeiro, % Brazil
%Journal of Biomechanics, 2024
% Developed by Luiz da Costa Nunes

close all
clear all

%TC19 removed
load stress3.dat %MPa
load stress4.dat
load stress6.dat
load stress8.dat
load stress9.dat
load stress10.dat
load stress12.dat
load stress13.dat
load stress15.dat
load stress17.dat
load stress19.dat

load strain3.dat
load strain4.dat
load strain6.dat
load strain8.dat
load strain9.dat
load strain10.dat
load strain12.dat
load strain13.dat
load strain15.dat
load strain17.dat
load strain19.dat

load shearmod3.dat %kPa
load shearmod4.dat
load shearmod6.dat
load shearmod8.dat
load shearmod9.dat
load shearmod10.dat
load shearmod12.dat
load shearmod13.dat
load shearmod15.dat
load shearmod17.dat
load shearmod19.dat

load Etg3.dat
load Etg4.dat
load Etg6.dat
load Etg8.dat
load Etg9.dat
load Etg10.dat
load Etg12.dat
load Etg13.dat
load Etg15.dat
load Etg17.dat

size(shearmod3)
size(Etg3)

% True strain
strain=log(strain3+1);
stress=stress3.*(strain3+1);
shearmod=shearmod3;

% Final part
k = find(stress>(stress(end)-7));
t1=stress(k(1):end);
d1=strain(k(1):end);
p1 = polyfit(d1,t1,1);
ta1=polyval(p1,d1);

Ef=p1(1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% curve fitting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x=stress(1:end);
y=strain(1:end);
e1 = fitoptions('Method','NonlinearLeastSquares',...
    'MaxFunEvals',1e3, ... 
     'MaxIter',1e3, ... 
      'TolFun', 1e-12, ... 
       'TolX', 1e-12, ... 
       'StartPoint',[1 1],'Lower',[0 0],'Upper',[1 80]);
   
mdl = fittype(@(e0,s0,x) e0*(1-exp(-x/s0))+x/Ef,'options',e1);

[fo1 go1] = fit(x,y,mdl);
e0r=fo1.e0;
s0r=fo1.s0;
ea=e0r*(1-exp(-x/s0r))+x/Ef;

%save ea ea -ascii

Ei=1/(e0r/s0r+1/Ef);
disp(go1);

der=diff(x)./diff(ea);
str1=stress(1:end-1);
dst1=diff(stress)./diff(strain);

% Shear modulus SSI
p2 = polyfit(stress,shearmod,1); % kPa/MPa
sm=polyval(p2,stress);
tenx=x;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p=150;
figure(7),
subplot(1,2,1)
plot(strain3(1:p:end),stress3(1:p:end),'>k','MarkerFaceColor','k'), hold on
plot(strain4(1:p:end),stress4(1:p:end),'ok'),
plot(strain6(1:120:end),stress6(1:120:end),'sk')
plot(strain8(1:p:end),stress8(1:p:end),'sk','MarkerFaceColor','k'),hold on
plot(strain9(1:200:end),stress9(1:200:end),'vk','MarkerFaceColor','k')
plot(strain10(1:300:end),stress10(1:300:end),'ok','MarkerFaceColor','k'),
plot(strain12(1:p:end),stress12(1:p:end),'vk')
plot(strain13(1:300:end),stress13(1:300:end),'dk','MarkerFaceColor','k'),
plot(strain15(1:p:end),stress15(1:p:end),'dk')
plot(strain17(1:400:end),stress17(1:400:end),'>k'),
plot(strain19(1:350:end),stress19(1:350:end),'or','MarkerFaceColor','r'),hold on
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
legend({'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10','S11'})
legend ('FontSize',12,'Location','northwest','box','off')
xlabel('$\varepsilon$ ','Interpreter','Latex','FontSize',18)
ylabel('\sigma (MPa)','FontName','Times New Roman','FontSize',18)
axis([0 0.05 0 70])
title('(A)','FontWeight','normal','FontSize',18)
subplot(1,2,2)
plot(stress3(1:p:end),shearmod3(1:p:end),'>k','MarkerFaceColor','k'), hold on
plot(stress4(1:p:end),shearmod4(1:p:end),'ok')
plot(stress6(1:120:end),shearmod6(1:120:end),'sk')
plot(stress8(1:p:end),shearmod8(1:p:end),'sk','MarkerFaceColor','k'),hold on
plot(stress9(1:p:end),shearmod9(1:p:end),'vk','MarkerFaceColor','k')
plot(stress10(1:300:end),shearmod10(1:300:end),'ok','MarkerFaceColor','k'),
plot(stress12(1:p:end),shearmod12(1:p:end),'vk')
plot(stress13(1:200:end),shearmod13(1:200:end),'dk','MarkerFaceColor','k'),
plot(stress15(1:p:end),shearmod15(1:p:end),'dk')
plot(stress17(1:400:end),shearmod17(1:400:end),'>k'),
plot(stress19(1:350:end),shearmod19(1:350:end),'or','MarkerFaceColor','r'),
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
legend({'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10','S11'})
legend ('FontSize',12,'Location','southeast','box','off')
xlabel('\sigma (MPa)','FontName','Times New Roman','FontSize',18)
ylabel('\mu_{SSI} (kPa)','FontName','Times New Roman','FontSize',18)
axis([0 70 30 250])
title('(B)','FontWeight','normal','FontSize',18)
f=figure(7);
set(f,'Position',[80 80 1000 400])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Ei %MPa
Ef %MPa
e0r
s0r %MPa
mu0=sm(1) %kPa
alfa=p2(1)*1e-3 %kPa/MPa

vEi=[199.1779 608.1745 919.7123 472.9376 2.1077e+03  349.1883 1.9604e+03 1.7109e+03 332.8739 461.4998];
vEf=[2030.8 3747.8 4202.5 5464.2 5825.7 3419.4 3699.5 5572.8  3180.8 2556.3];
ve0=[0.0361 0.0128 0.0086 0.0152 0.0045 0.0168 0.0022 0.0064 0.0274  0.0114];
vs0=[7.9656 9.3124 10.1254 7.8914 14.9249 6.5332 9.3464 15.9062 10.1766 6.4208];
vmu=[107.5988 56  78.8286 102.9613 65.6014 48.5986 85.7628 88.5717 48.9246  106.7294];
valfa=[2.5369e-03 2.8771e-03 2.8988e-03 2.5622e-03 1.7325e-03 4.5285e-03 4.7894e-03 1.9824e-03 1.9907e-03 4.9367e-03];

X = categorical({'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10'});
X = reordercats(X,{'S1','S2','S3','S4','S5','S6','S7','S8','S9','S10'});

figure(9),
subplot(3,2,1)
bar(X,vEi*1e-3,'FaceColor',[.7 .7 .7])
set(gca,'FontSize',14) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Samples','FontName','Times New Roman','FontSize',18)
ylabel('\itE_{cri} \rm(GPa)','FontName','Times New Roman','FontSize',18)
title('(A)','FontWeight','normal','FontSize',18)

subplot(3,2,2)
bar(X,vEf*1e-3,'FaceColor',[.7 .7 .7])
set(gca,'FontSize',14) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Samples','FontName','Times New Roman','FontSize',18)
ylabel('\itE_{str} \rm(GPa)','FontName','Times New Roman','FontSize',18)
title('(B)','FontWeight','normal','FontSize',18)

subplot(3,2,3)
bar(X,ve0,'FaceColor',[.7 .7 .7])
set(gca,'FontSize',14) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Samples','FontName','Times New Roman','FontSize',18)
ylabel('$\varepsilon_{0}$ ','Interpreter','Latex','FontSize',18)
title('(C)','FontWeight','normal','FontSize',18)

subplot(3,2,4)
bar(X,vs0,'FaceColor',[.7 .7 .7])
set(gca,'FontSize',14) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Samples','FontName','Times New Roman','FontSize',18)
ylabel('\sigma_{0} (MPa)','FontName','Times New Roman','FontSize',16)
title('(D)','FontWeight','normal','FontSize',18)

subplot(3,2,5)
bar(X,vmu,'FaceColor',[.7 .7 .7])
set(gca,'FontSize',14) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Samples','FontName','Times New Roman','FontSize',18)
ylabel('\mu_{SSI0} (kPa)','FontName','Times New Roman','FontSize',18)
title('(E)','FontWeight','normal','FontSize',18)

subplot(3,2,6)
bar(X,valfa*1e3,'FaceColor',[.7 .7 .7])
set(gca,'FontSize',14) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Samples','FontName','Times New Roman','FontSize',18)
ylabel('\alpha (x 10^{-3})','FontName','Times New Roman','FontSize',18)
title('(F)','FontWeight','normal','FontSize',18)

f=figure(9);
set(f,'Position',[100 100 800 800])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Estatistica_Ei = [std(vEi) mean(vEi) std(vEi)/mean(vEi)]
Estatistica_Ef = [std(vEf) mean(vEf) std(vEf)/mean(vEf)]
Estatistica_e0 = [std(ve0) mean(ve0) std(ve0)/mean(ve0)]
Estatistica_s0 = [std(vs0) mean(vs0) std(vs0)/mean(vs0)]
Estatistica_mu = [std(vmu) mean(vmu) std(vmu)/mean(vmu)]
Estatistica_alfa = [std(valfa) mean(valfa) std(valfa)/mean(valfa)]

% all MPa
xussi=(50:250);
inEtan1=(1/vEi(1)-1/vEf(1))*exp(-((xussi-vmu(1))*1e-3)/(valfa(1)*vs0(1)))+1/vEf(1);
inEtan2=(1/vEi(2)-1/vEf(2))*exp(-((xussi-vmu(2))*1e-3)/(valfa(2)*vs0(2)))+1/vEf(2);
inEtan3=(1/vEi(3)-1/vEf(3))*exp(-((xussi-vmu(3))*1e-3)/(valfa(3)*vs0(3)))+1/vEf(3);
inEtan4=(1/vEi(4)-1/vEf(4))*exp(-((xussi-vmu(4))*1e-3)/(valfa(4)*vs0(4)))+1/vEf(4);
inEtan5=(1/vEi(5)-1/vEf(5))*exp(-((xussi-vmu(5))*1e-3)/(valfa(5)*vs0(5)))+1/vEf(5);
inEtan6=(1/vEi(6)-1/vEf(6))*exp(-((xussi-vmu(6))*1e-3)/(valfa(6)*vs0(6)))+1/vEf(6);
inEtan7=(1/vEi(7)-1/vEf(7))*exp(-((xussi-vmu(7))*1e-3)/(valfa(7)*vs0(7)))+1/vEf(7);
inEtan8=(1/vEi(8)-1/vEf(8))*exp(-((xussi-vmu(8))*1e-3)/(valfa(8)*vs0(8)))+1/vEf(8);
inEtan9=(1/vEi(9)-1/vEf(9))*exp(-((xussi-vmu(9))*1e-3)/(valfa(9)*vs0(9)))+1/vEf(9);
inEtan10=(1/vEi(10)-1/vEf(10))*exp(-((xussi-vmu(10))*1e-3)/(valfa(10)*vs0(10)))+1/vEf(10);

Etan1=1./inEtan1;
Etan2=1./inEtan2;
Etan3=1./inEtan3;
Etan4=1./inEtan4;
Etan5=1./inEtan5;
Etan6=1./inEtan6;
Etan7=1./inEtan7;
Etan8=1./inEtan8;
Etan9=1./inEtan9;
Etan10=1./inEtan10;

w=120;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mEtan=mean([Etan1; Etan2; Etan3; Etan4; Etan5; Etan6; Etan7; Etan8; Etan9; Etan10],1);
sdEtan=std([Etan1; Etan2; Etan3; Etan4; Etan5; Etan6; Etan7; Etan8; Etan9; Etan10],1);

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mEtan=mean([Etan1; Etan2; Etan3; Etan4; Etan6; Etan9; Etan10],1);
sdEtan=std([Etan1; Etan2; Etan3; Etan4; Etan6; Etan9; Etan10],1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% diameter
dia=[12 13 12 12 9 13 16 10 12 16];
compin=[71 136 142 147 130 205 212 134 80 212];

%volume
vol=compin.*pi.*(dia/2).^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p=150;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(300),
clf
subplot(3,2,1)
plot(pi*(dia/2).^2,vEi,'ok','MarkerFaceColor','k','MarkerSize',8), hold on
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Area (mm^{2})','FontName','Times New Roman','FontSize',18)
ylabel('\itE_{cri} \rm(GPa)','FontName','Times New Roman','FontSize',18)
title('(A)','FontWeight','normal','FontSize',18)
xx=pi*(dia/2).^2;
yy=vEi;
[ro, p]=corr(xx',yy','type','pearson')
P1 = polyfit(xx,yy,1);
xx2=min(xx):0.01:max(xx);
yy2 = polyval(P1,xx2);
hold on
plot(xx2,yy2,'k','LineWidth',2)
text(1.7/3*max(xx),2/3*max(yy),num2str([ro p P1],'%.2f %.2f %.2f %.2f'))

subplot(3,2,2)
plot(pi*(dia/2).^2,vEf,'ok','MarkerFaceColor','k','MarkerSize',8), hold on
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Area (mm^{2})','FontName','Times New Roman','FontSize',18)
ylabel('\itE_{str} \rm(GPa)','FontName','Times New Roman','FontSize',18)
title('(B)','FontWeight','normal','FontSize',18)
xx=pi*(dia/2).^2;
yy=vEf;
[ro, p]=corr(xx',yy','type','pearson')
P1 = polyfit(xx,yy,1);
xx2=min(xx):0.01:max(xx);
yy2 = polyval(P1,xx2);
hold on
plot(xx2,yy2,'k','LineWidth',2)
text(1.6/3*max(xx),2.5/3*max(yy),num2str([ro p P1],'%.2f %.2f %.2f %.2f'))

subplot(3,2,3)
plot(compin,ve0,'ok','MarkerFaceColor','k','MarkerSize',8), hold on
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Length (mm)','FontName','Times New Roman','FontSize',18)
ylabel('$\varepsilon_{0}$ ','Interpreter','Latex','FontSize',18)
title('(C)','FontWeight','normal','FontSize',18)
xx=compin;
yy=ve0;
[ro, p]=corr(xx',yy','type','pearson')
P1 = polyfit(xx,yy,1);
xx2=min(xx):0.01:max(xx);
yy2 = polyval(P1,xx2);
hold on
plot(xx2,yy2,'k','LineWidth',2)
text(1.7/3*max(xx),2.5/3*max(yy),num2str([ro p P1],'%.2f %.2f %.2f %.2f'))

subplot(3,2,4)
plot(pi*(dia/2).^2,vs0,'ok','MarkerFaceColor','k','MarkerSize',8), hold on
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Area (mm^{2})','FontName','Times New Roman','FontSize',18)
ylabel('\sigma_{0} (MPa)','FontName','Times New Roman','FontSize',18)
title('(D)','FontWeight','normal','FontSize',18)
xx=pi*(dia/2).^2;
yy=vs0;
[ro, p]=corr(xx',yy','type','pearson')
P1 = polyfit(xx,yy,1);
xx2=min(xx):0.01:max(xx);
yy2 = polyval(P1,xx2);
hold on
plot(xx2,yy2,'k','LineWidth',2)
text(1.7/3*max(xx),2.5/3*max(yy),num2str([ro p P1],'%.2f %.2f %.2f %.2f'))

subplot(3,2,5)
plot(pi*(dia/2).^2,vmu,'ok','MarkerFaceColor','k','MarkerSize',8), hold on
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Area (mm^{2})','FontName','Times New Roman','FontSize',18)
ylabel('\mu_{SSI0} (kPa)','FontName','Times New Roman','FontSize',18)
title('(E)','FontWeight','normal','FontSize',18)
xx=pi*(dia/2).^2;
yy=vmu;
[ro, p]=corr(xx',yy','type','pearson')
P1 = polyfit(xx,yy,1);
xx2=min(xx):0.01:max(xx);
yy2 = polyval(P1,xx2);
hold on
plot(xx2,yy2,'k','LineWidth',2)
text(1.7/3*max(xx),2/3*max(yy),num2str([ro p P1],'%.2f %.2f %.2f %.2f'))

subplot(3,2,6)
plot(pi*(dia/2).^2,valfa*1e3,'ok','MarkerFaceColor','k','MarkerSize',8), hold on
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('Area (mm^{2})','FontName','Times New Roman','FontSize',18)
ylabel('\alpha (\times10^{-3})','FontName','Times New Roman','FontSize',18)
title('(F)','FontWeight','normal','FontSize',18)
xx=pi*(dia/2).^2;
yy=valfa*1e3;
[ro, p]=corr(xx',yy','type','pearson')
P1 = polyfit(xx,yy,1);
xx2=min(xx):0.01:max(xx);
yy2 = polyval(P1,xx2);
hold on
plot(xx2,yy2,'k','LineWidth',2)
text(2/3*max(xx),1.4/3*max(yy),num2str([ro p P1],'%.2f %.2f %.2f %.2f'))

f=figure(300);
set(f,'Position',[100 100 800 800])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

strainb=log(strain9+1);
stressb=stress9.*(strain9+1);
xb=stressb;
shearmodb=shearmod9;
load ea2.dat
p2b = polyfit(stressb,shearmodb,1); % kPa/MPa
smb=polyval(p2b,stressb);

p=150;
figure(101),
subplot(3,3,1)
plot(strain(1:p:end),stress(1:p:end),'>k','MarkerFaceColor','k'), hold on
plot(strainb(1:300:end),stressb(1:300:end),'ok'), hold on
plot(ea,x,'-k','LineWidth',1.3),hold on
plot(ea2,xb,'-k','LineWidth',1.3),hold on
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
legend({'Experimental data - S1','Experimental data - S5','Equation (1)'})
legend ('FontSize',14,'Location','northeast','box','off')
xlabel('$\varepsilon$ ','Interpreter','Latex','FontSize',18)
ylabel('\sigma (MPa)','FontName','Times New Roman','FontSize',18)
axis([0 0.055 0 50])
title('(A)','FontWeight','normal','FontSize',18)

subplot(3,3,2)
plot(stress, abs((strain-ea)./ea)*100,'-k','LineWidth',1.3),hold on
plot(stressb, abs((strainb-ea2)./ea2)*100,'--k','LineWidth',1.3),hold on
legend({'S1','S5'})
legend ('FontSize',14,'Location','northeast','box','off')
axis([0 50 0 10])
set(gcf,'Color',[1,1,1]) % figura
xlabel('\sigma (MPa)','FontName','Times New Roman','FontSize',18)
ylabel('|(\epsilon_{\itexp\rm}-\epsilon_{\itmodel\rm})/\epsilon_{\itmodel\rm}| (%)','FontName','Times New Roman','FontSize',18)
set(gca,'FontSize',16) % eixos
title('(B)','FontWeight','normal','FontSize',18)

subplot(3,3,4)
plot(strain(1:p:end),stress(1:p:end),'>k','MarkerFaceColor','k'), hold on
plot(strainb(1:300:end),stressb(1:300:end),'ok'), hold on
plot(0.0335+stress/1.85e3,stress,'-k','LineWidth',1.3),hold on
plot(0.0033+stressb/5.2e3,stressb,'-k','LineWidth',1.3),hold on
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
legend({'Experimental data - S1','Experimental data - S5','Linear fit'})
%legend({'Experimental data - S1','Experimental data - S5','Equation (1)','Linear fit'})
legend ('FontSize',14,'Location','best','box','off')
xlabel('$\varepsilon$ ','Interpreter','Latex','FontSize',18)
ylabel('\sigma (MPa)','FontName','Times New Roman','FontSize',18)
axis([0 0.055 0 40])
title('(C)','FontWeight','normal','FontSize',18)

subplot(3,3,5)
plot(stress,abs((strain-(0.0335+stress/1.85e3))./strain)*100,'-k','LineWidth',1.3),hold on
plot(stressb,abs((strainb-(0.0033+stressb/5.2e3))./strainb)*100,'--k','LineWidth',1.3),hold on
legend({'S1','S5'})
legend ('FontSize',14,'Location','northeast','box','off')
axis([0 50 0 10])
set(gcf,'Color',[1,1,1]) % figura
xlabel('\sigma (MPa)','FontName','Times New Roman','FontSize',18)
ylabel('|(\epsilon_{\itexp\rm}-\epsilon_{\itmodel\rm})/\epsilon_{\itmodel\rm}| (%)','FontName','Times New Roman','FontSize',18)
set(gca,'FontSize',16) % eixos
title('(D)','FontWeight','normal','FontSize',18)

subplot(3,3,7)
plot(shearmod3(1:p:end),stress(1:p:end),'>k','MarkerFaceColor','k'), hold on
plot(shearmod9(1:p:end),stressb(1:p:end),'ok'), hold on
plot(sm,stress,'-k','LineWidth',1.3)
plot(smb,stressb,'-k','LineWidth',1.3)
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
legend({'Experimental data - S1','Experimental data - S5','Equation (4)'})
legend ('FontSize',14,'Location','northwest','box','off')
xlabel('\mu_{SSI} (kPa)','FontName','Times New Roman','FontSize',18)
ylabel('\sigma (MPa)','FontName','Times New Roman','FontSize',18)
%axis([0 70 30 250])
title('(E)','FontWeight','normal','FontSize',18)

subplot(3,3,8)
plot(stress, abs((shearmod-sm)./sm)*100,'-k','LineWidth',1.3),hold on
plot(stressb, abs((shearmodb-smb)./smb)*100,'--k','LineWidth',1.3)
legend({'S1','S5'})
legend ('FontSize',14,'Location','northeast','box','off')
xlabel('\sigma (MPa)','FontName','Times New Roman','FontSize',18)
ylabel('|(\mu_{\itexp\rm}-\mu_{\itmodel\rm})/\mu_{\itmodel\rm}| (%)','FontName','Times New Roman','FontSize',18)
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
title('(F)','FontWeight','normal','FontSize',18)

subplot(3,3,6)
g=130;
plot(xussi,Etan1*1e-3,'-k','LineWidth',1.3), hold on
plot(xussi,Etan5*1e-3,'-k','LineWidth',2.3), hold on
plot(xussi(g:end),1.85*ones(length(xussi(g:end))),'--k','LineWidth',1.3), hold on
plot(xussi(80:end),5.2*ones(length(xussi(80:end))),'--k','LineWidth',1.3), hold on
legend({'Equation (5) - S1','Equation (5) - S5','Slope of linear fit'})
legend ('FontSize',16,'Location','northwest','box','off')
%axis([100 220 0 2])
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('\mu_{SSI} (kPa)','FontName','Times New Roman','FontSize',18)
ylabel('\itE_{tan}\rm (GPa)','FontName','Times New Roman','FontSize',18)
title('(G)','FontWeight','normal','FontSize',18)

f=figure(101);
set(f,'Position',[100 100 1400 900])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(301),
subplot(2,2,1)
plot(stress3(1:70:end),Etg3(1:70:end)*1e-3,'ok'),hold on
plot(x(1:end-1),der*1e-3,'-k','LineWidth',1.3)
legend({'Brandão approach (2023)','Equation (2)'})
legend ('FontSize',16,'Location','northwest','box','off')
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('\sigma (MPa)','FontName','Times New Roman','FontSize',18)
ylabel('\itE_{tan}\rm (GPa)','FontName','Times New Roman','FontSize',18)
title('(A)','FontWeight','normal','FontSize',18)

subplot(2,2,2)
plot(shearmod3(1:w:end),Etg3(1:w:end)*1e-3,'ko'), hold on
plot(xussi,Etan1*1e-3,'-k','LineWidth',1.3)
legend({'Brandão approach (2023)','Equation (5)'})
legend ('FontSize',16,'Location','northwest','box','off')
axis([100 220 0 2])
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('\mu_{SSI} (kPa)','FontName','Times New Roman','FontSize',18)
ylabel('\itE_{tan}\rm (GPa)','FontName','Times New Roman','FontSize',18)
title('(B)','FontWeight','normal','FontSize',18)

subplot(2,2,3.5)
plot(shearmod3(1:w:end),Etg3(1:w:end)*1e-3,'ko'), hold on
plot(xussi,Etan1*1e-3,'-k','LineWidth',1.3)
plot(xussi,Etan2*1e-3,'-y','LineWidth',1.3)
plot(shearmod4(1:w:end),Etg4(1:w:end)*1e-3,'yo')
plot(xussi,Etan3*1e-3,'-b','LineWidth',1.3)
plot(shearmod6(1:w:end),Etg6(1:w:end)*1e-3,'bo')
plot(xussi,Etan4*1e-3,'-r','LineWidth',1.3)
plot(shearmod8(1:w:end),Etg8(1:w:end)*1e-3,'ro')
plot(xussi,Etan5*1e-3,'-','Color',"#0072BD",'LineWidth',1.3)
plot(shearmod9(1:w:end),Etg9(1:w:end)*1e-3,'o','Color',"#0072BD")
plot(xussi,Etan6*1e-3,'-c','LineWidth',1.3)
plot(shearmod10(1:w:end),Etg10(1:w:end)*1e-3,'co')
plot(xussi,Etan7*1e-3,'-k','LineWidth',1.3)
plot(shearmod12(1:w:end),Etg12(1:w:end)*1e-3,'ko')
plot(xussi,Etan8*1e-3,'-g','LineWidth',1.3)
plot(shearmod13(1:w:end),Etg13(1:w:end)*1e-3,'go')
plot(xussi,Etan9*1e-3,'-r','Color',"#EDB120",'LineWidth',1.3)
plot(shearmod15(1:w:end),Etg15(1:w:end)*1e-3,'ro','Color',"#EDB120")
plot(xussi,Etan10*1e-3,'-m','LineWidth',1.3)
plot(shearmod17(1:w:end),Etg17(1:w:end)*1e-3,'mo')
legend({'Brandão approach (2023)','Equation (5)'})
legend ('FontSize',16,'Location','northwest','box','off')
axis([50 250 0 7])
set(gca,'FontSize',16) % eixos
set(gcf,'Color',[1,1,1]) % figura
xlabel('\mu_{SSI} (kPa)','FontName','Times New Roman','FontSize',18)
ylabel('\itE_{tan}\rm (GPa)','FontName','Times New Roman','FontSize',18)
title('(C)','FontWeight','normal','FontSize',18)
f=figure(301);
set(f,'Position',[100 100 900 700])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
